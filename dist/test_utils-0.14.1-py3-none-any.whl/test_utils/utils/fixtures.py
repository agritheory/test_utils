#!/usr/bin/python

import json

from rich.console import Console
from rich.table import Table
from rich import inspect

import requests


repo_config = [
    ("beam", "https://github.com/agritheory/beam", "version-14"),
    ("check_run", "https://github.com/agritheory/check_run", "tax_payable"),
    ("inventory_tools", "https://github.com/agritheory/inventory_tools", "version-14"),
    (
        "electronic_payments",
        "https://github.com/agritheory/electronic_payments",
        "version-14",
    )
    # ("us_regional", "https://github.com/agritheory/us_regional", "version-15"), # need to refactor to use pygithub to access private repos
]

fixtures_data = {}


def get_fixtures_data(repo, branch="version-14"):
    repo_string = f'{repo[1].replace("https://github.com/", "https://raw.githubusercontent.com/")}/{branch}/{repo[0]}/tests/fixtures.py'
    fixtures_text = requests.get(repo_string).text
    exec(fixtures_text)
    for key, value in vars().items():
        if key in ("repo", "branch", "fixtures_text", "repo_string"):
            continue
        if not fixtures_data.get(key):
            fixtures_data[key] = {}
        fixtures_data[key][repo[0]] = value


def diff_fixtures():
    console = Console()
    output = {}

    for fixture, repos in fixtures_data.items():
        output[fixture] = {}
        for repo_name, values in repos.items():
            for value in values:
                if type(value) == str:
                    continue
                if isinstance(value, tuple):
                    value = list(value)
            output[fixture][repo_name] = json.dumps(values, indent=2)

    for key, value in output.items():
        print(key, value.keys(), [len(v) for v in value.values()])

    for fixture, repos in output.items():
        table = Table(show_header=True, header_style="bold magenta", title=fixture)
        for repo_name, values in repos.items():
            table.add_column(repo_name)
        table.add_row(*list(repos.values()))
        console.print(table)


if __name__ == "__main__":
    for repo in repo_config:
        get_fixtures_data(repo)

    diff_fixtures()
